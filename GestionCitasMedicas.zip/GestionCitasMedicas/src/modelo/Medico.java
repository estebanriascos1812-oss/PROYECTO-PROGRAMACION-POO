package modelo;

public class Medico extends Persona {
    private String especialidad;

    public Medico(String nombre, String documento, String especialidad) {
        super(nombre, documento);
        this.especialidad = especialidad;
    }
    public String getEspecialidad() { return especialidad; }
}