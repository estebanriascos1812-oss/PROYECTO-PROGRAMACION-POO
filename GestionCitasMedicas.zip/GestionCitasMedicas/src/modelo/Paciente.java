package modelo;

public class Paciente extends Persona {
    private String historial;
    public Paciente(String nombre, String documento, String historial) {
        super(nombre, documento); // Llama al constructor de Persona
        this.historial = historial;
    }
}

