package modelo;

public class Cita {
    private String fecha;
    private String hora;
    private Paciente paciente; // Relación con objeto Paciente
    private Medico medico;     // Relación con objeto Medico

    public Cita(String fecha, String hora, Paciente paciente, Medico medico) {
        this.fecha = fecha;
        this.hora = hora;
        this.paciente = paciente;
        this.medico = medico;
    }
    // Getters para acceder a los datos desde el Controlador
}